package problemaSerie3.exceptions;

public class InvalidFileFormatException extends Exception {

    public InvalidFileFormatException(String msg) {
        super(msg);
    }

    public InvalidFileFormatException() {}
}
